<?php

class Credentials {

    // Declare the credentials to the database
    public $servername = "mydbinstance.cfz8vkgrvazf.us-east-1.rds.amazonaws.com";
    public $serverusername = "lambdatestuser";
    public $serverpassword = "Nini*12345";
    public $serverdb = "it5236db";

}

?>
