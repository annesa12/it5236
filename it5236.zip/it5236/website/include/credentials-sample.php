<?php

class Credentials {

    // Declare the credentials to the database
    public $servername = "localhost";
    public $serverusername = "root";
    public $serverpassword = "hunter2";
    public $serverdb = "it5236";

}

?>
